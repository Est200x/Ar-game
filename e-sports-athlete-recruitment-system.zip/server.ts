import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";

const PORT = 3000;
const DB_FILE = path.join(process.cwd(), "database.json");

// Helper to read database
function readDB() {
  if (!fs.existsSync(DB_FILE)) {
    // Initial seeded users
    const initialData = {
      users: [
        {
          id: 1,
          username: "pro_gamer",
          password: "password123", // Simulated (not real secure hash, but fine for preview)
          name: "กฤษฎา พรหมสุวรรณ (Seeded Pro)",
          email: "kritsada@esports.com",
          high_score: 45
        },
        {
          id: 2,
          username: "neon_striker",
          password: "password123",
          name: "ชลลดา วงศ์เทวา (Seeded Semi-Pro)",
          email: "chonlada@esports.com",
          high_score: 38
        }
      ]
    };
    fs.writeFileSync(DB_FILE, JSON.stringify(initialData, null, 2), "utf-8");
    return initialData;
  }
  try {
    const content = fs.readFileSync(DB_FILE, "utf-8");
    return JSON.parse(content);
  } catch (e) {
    return { users: [] };
  }
}

// Helper to write database
function writeDB(data: any) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), "utf-8");
}

async function startServer() {
  const app = express();
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Simulate server-side session
  let activeSession: any = null;

  // --- API Endpoints ---

  // Register
  app.post("/api/register", (req, res) => {
    const { name, email, username, password } = req.body;
    if (!name || !email || !username || !password) {
      return res.status(400).json({ success: false, message: "กรุณากรอกข้อมูลให้ครบถ้วน" });
    }

    const db = readDB();
    const userExists = db.users.find((u: any) => u.username.toLowerCase() === username.toLowerCase());
    if (userExists) {
      return res.status(400).json({ success: false, message: "ชื่อผู้ใช้นี้ถูกใช้งานแล้ว" });
    }

    const newUser = {
      id: db.users.length + 1,
      username,
      password, // Plain text for simplicity in preview, hashed in PHP code
      name,
      email,
      high_score: 0
    };

    db.users.push(newUser);
    writeDB(db);

    return res.json({ success: true, message: "สมัครสมาชิกสำเร็จ!" });
  });

  // Login
  app.post("/api/login", (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ success: false, message: "กรุณากรอกข้อมูลให้ครบถ้วน" });
    }

    const db = readDB();
    const user = db.users.find(
      (u: any) => u.username.toLowerCase() === username.toLowerCase() && u.password === password
    );

    if (user) {
      activeSession = {
        id: user.id,
        username: user.username,
        name: user.name,
        email: user.email,
        high_score: user.high_score
      };
      return res.json({ success: true, user: activeSession });
    } else {
      return res.status(400).json({ success: false, message: "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง" });
    }
  });

  // Get Current User / Session Check
  app.get("/api/current-user", (req, res) => {
    return res.json({ user: activeSession });
  });

  // Update Score
  app.post("/api/update-score", (req, res) => {
    if (!activeSession) {
      return res.status(401).json({ success: false, message: "Unauthorized access" });
    }

    const score = parseInt(req.body.score, 10);
    if (isNaN(score) || score < 0) {
      return res.status(400).json({ success: false, message: "คะแนนไม่ถูกต้อง" });
    }

    const db = readDB();
    const userIdx = db.users.findIndex((u: any) => u.id === activeSession.id);
    if (userIdx !== -1) {
      const user = db.users[userIdx];
      let newRecord = false;
      if (score > user.high_score) {
        db.users[userIdx].high_score = score;
        writeDB(db);
        activeSession.high_score = score;
        newRecord = true;
      }
      return res.json({ success: true, new_record: newRecord, high_score: db.users[userIdx].high_score });
    }

    return res.status(400).json({ success: false, message: "ไม่พบผู้ใช้" });
  });

  // Logout
  app.post("/api/logout", (req, res) => {
    activeSession = null;
    return res.json({ success: true });
  });

  // Leaderboard endpoint
  app.get("/api/leaderboard", (req, res) => {
    const db = readDB();
    const leaderboard = db.users
      .map((u: any) => ({
        id: u.id,
        username: u.username,
        name: u.name,
        high_score: u.high_score
      }))
      .sort((a: any, b: any) => b.high_score - a.high_score);
    return res.json({ success: true, leaderboard });
  });

  // PHP Source code endpoint so we can display it beautifully in our code tab
  app.get("/api/php-source", (req, res) => {
    const xampDir = path.join(process.cwd(), "xampp");
    try {
      const schemaSql = fs.readFileSync(path.join(xampDir, "schema.sql"), "utf-8");
      const configPhp = fs.readFileSync(path.join(xampDir, "config.php"), "utf-8");
      const indexPhp = fs.readFileSync(path.join(xampDir, "index.php"), "utf-8");
      const registerPhp = fs.readFileSync(path.join(xampDir, "register.php"), "utf-8");
      const gamePhp = fs.readFileSync(path.join(xampDir, "game.php"), "utf-8");
      const updateScorePhp = fs.readFileSync(path.join(xampDir, "update_score.php"), "utf-8");
      const logoutPhp = fs.readFileSync(path.join(xampDir, "logout.php"), "utf-8");

      return res.json({
        success: true,
        files: {
          "schema.sql": schemaSql,
          "config.php": configPhp,
          "index.php": indexPhp,
          "register.php": registerPhp,
          "game.php": gamePhp,
          "update_score.php": updateScorePhp,
          "logout.php": logoutPhp
        }
      });
    } catch (e: any) {
      return res.status(500).json({ success: false, message: "Failed to read PHP files: " + e.message });
    }
  });

  // Vite middleware for development or Static server for production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
