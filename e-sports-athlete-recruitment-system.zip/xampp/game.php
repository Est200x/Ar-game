<?php
// game.php - Mini AR Hand Tracking Game
require_once 'config.php';

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$name = $_SESSION['name'];
$username = $_SESSION['username'];
$high_score = $_SESSION['high_score'];
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AR Hand Game | มินิเกมจับภาพมือสะสมคะแนน</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts: Orbitron & Prompt -->
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Prompt:wght@300;400;600;700&display=swap" rel="stylesheet">
    <!-- MediaPipe Hands & Camera CDNs -->
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js" crossorigin="anonymous"></script>
    <style>
        :root {
            --bg-dark: #0a0a16;
            --card-bg: rgba(15, 15, 35, 0.75);
            --neon-blue: #00f0ff;
            --neon-pink: #ff007f;
            --neon-green: #39ff14;
            --text-light: #e2e8f0;
        }

        body {
            background-color: var(--bg-dark);
            background-image: 
                radial-gradient(at 10% 20%, rgba(0, 240, 255, 0.08) 0px, transparent 50%),
                radial-gradient(at 90% 80%, rgba(255, 0, 127, 0.1) 0px, transparent 50%);
            color: var(--text-light);
            font-family: 'Prompt', sans-serif;
            min-height: 100vh;
        }

        .heading-esports {
            font-family: 'Orbitron', sans-serif;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 2px;
            text-shadow: 0 0 10px rgba(0, 240, 255, 0.6);
            color: var(--neon-blue);
        }

        .neon-card {
            background: var(--card-bg);
            border: 1px solid rgba(0, 240, 255, 0.2);
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.37);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            border-radius: 15px;
        }

        .btn-neon-blue {
            background: transparent;
            border: 2px solid var(--neon-blue);
            color: var(--neon-blue);
            font-family: 'Orbitron', sans-serif;
            font-weight: 700;
            transition: all 0.3s ease;
        }

        .btn-neon-blue:hover:not(:disabled) {
            background: var(--neon-blue);
            color: var(--bg-dark);
            box-shadow: 0 0 15px var(--neon-blue);
        }

        .btn-neon-pink {
            background: transparent;
            border: 2px solid var(--neon-pink);
            color: var(--neon-pink);
            font-family: 'Orbitron', sans-serif;
            font-weight: 700;
            transition: all 0.3s ease;
        }

        .btn-neon-pink:hover {
            background: var(--neon-pink);
            color: #fff;
            box-shadow: 0 0 15px var(--neon-pink);
        }

        .game-panel {
            position: relative;
            width: 100%;
            max-width: 640px;
            aspect-ratio: 4/3;
            background: #02020a;
            border: 2px solid rgba(0, 240, 255, 0.3);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 0 25px rgba(0, 240, 255, 0.15);
        }

        #webcam {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            transform: scaleX(-1); /* Flip horizontal */
            opacity: 0.35; /* Blends camera into the dark gaming background */
            z-index: 1;
        }

        #game-canvas {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 2;
            cursor: crosshair;
        }

        .stat-box {
            background: rgba(0, 0, 0, 0.5);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 10px 15px;
            min-width: 120px;
            text-align: center;
        }

        .stat-value {
            font-family: 'Orbitron', sans-serif;
            font-weight: 700;
            font-size: 1.5rem;
        }

        .stat-value.blue { color: var(--neon-blue); text-shadow: 0 0 8px rgba(0, 240, 255, 0.5); }
        .stat-value.pink { color: var(--neon-pink); text-shadow: 0 0 8px rgba(255, 0, 127, 0.5); }
        .stat-value.green { color: var(--neon-green); text-shadow: 0 0 8px rgba(57, 255, 20, 0.5); }

        .form-select {
            background-color: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: #fff;
        }

        .form-select:focus {
            background-color: rgba(255, 255, 255, 0.08);
            border-color: var(--neon-blue);
            color: #fff;
            box-shadow: 0 0 10px rgba(0, 240, 255, 0.25);
        }

        /* Mode alert banner */
        .mode-banner {
            font-size: 0.85rem;
            letter-spacing: 0.5px;
        }
    </style>
</head>
<body>

<!-- Navbar/Header -->
<nav class="navbar navbar-expand-lg border-bottom border-secondary border-opacity-25 py-3">
    <div class="container">
        <span class="navbar-brand heading-esports fs-4">PRO-SELECTION</span>
        <div class="d-flex align-items-center gap-3">
            <div class="text-end d-none d-sm-block">
                <span class="text-muted small">ผู้สมัครทดสอบ:</span>
                <div class="fw-bold text-info"><?php echo htmlspecialchars($name); ?> (@<?php echo htmlspecialchars($username); ?>)</div>
            </div>
            <a href="logout.php" class="btn btn-neon-pink btn-sm px-3">LOGOUT</a>
        </div>
    </div>
</nav>

<div class="container py-4">
    <div class="row g-4">
        <!-- Sidebar stats and info -->
        <div class="col-lg-4">
            <div class="neon-card p-4 h-100 d-flex flex-column justify-content-between">
                <div>
                    <h4 class="text-info mb-3 border-bottom border-secondary border-opacity-25 pb-2">คะแนนสถิติ</h4>
                    
                    <div class="d-flex gap-2 flex-wrap mb-4">
                        <div class="stat-box flex-fill">
                            <div class="text-muted small">High Score</div>
                            <div class="stat-value blue" id="display-high-score"><?php echo $high_score; ?></div>
                        </div>
                        <div class="stat-box flex-fill">
                            <div class="text-muted small">คะแนนปัจจุบัน</div>
                            <div class="stat-value green" id="display-current-score">0</div>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="control-mode" class="form-label text-warning fw-bold">เลือกโหมดการควบคุม</label>
                        <select class="form-select" id="control-mode">
                            <option value="webcam">Webcam (AR Hand Tracking)</option>
                            <option value="mouse">Mouse / Touch Screen (Fallback)</option>
                        </select>
                        <div class="mode-banner mt-2 text-muted small" id="mode-desc">
                            * ใช้กล้องเพื่อตรวจจับความเคลื่อนไหวข้อมือเพื่อควบคุมพอยต์เตอร์กลมสีแดงเลื่อนไปเก็บดวงดาวบนจอ
                        </div>
                    </div>

                    <div class="alert alert-info bg-info bg-opacity-10 border-info border-opacity-20 text-info small" role="alert">
                        ⚡ <strong>เทคนิคเก็บแต้ม:</strong> เคลื่อนข้อมือ/เมาส์ ไปวางบนดวงดาวเพื่อทำคะแนนให้เร็วที่สุด ดนตรีสังเคราะห์เสียงจะดังขึ้นเมื่อทำคะแนนสำเร็จ!
                    </div>
                </div>

                <div class="mt-4 pt-3 border-top border-secondary border-opacity-25">
                    <button class="btn btn-neon-blue w-100 py-3 fs-5" id="btn-start">START TEST (30s)</button>
                    <button class="btn btn-secondary w-100 py-2.5 mt-2 d-none" id="btn-restart">RESTART</button>
                </div>
            </div>
        </div>

        <!-- Main Game Area -->
        <div class="col-lg-8">
            <div class="neon-card p-4 text-center d-flex flex-column align-items-center">
                <div class="d-flex justify-content-between w-100 mb-3 align-items-center">
                    <h4 class="heading-esports text-start m-0">LIVE ARENA</h4>
                    <div class="stat-box py-1 px-3 d-flex align-items-center gap-2">
                        <span class="text-muted small">Time Left:</span>
                        <span class="stat-value pink fs-4" id="display-timer">30s</span>
                    </div>
                </div>

                <!-- Game Container -->
                <div class="game-panel">
                    <video id="webcam" autoplay playsinline muted></video>
                    <canvas id="game-canvas" width="640" height="480"></canvas>
                </div>

                <!-- Status Overlay message -->
                <div class="mt-3 text-muted small" id="camera-status">
                    * กรุณากดปุ่ม START TEST และอนุญาตใช้งานกล้องของคุณเพื่อเริ่มการตรวจจับ
                </div>
            </div>
        </div>
    </div>
</div>

<footer class="text-center py-4 mt-4 border-top border-secondary border-opacity-25">
    <p class="text-muted small mb-0">© 2026 E-Sports Selection Portal. All Rights Reserved.</p>
</footer>

<!-- Sound Synthesizer & Game Logic Script -->
<script>
// --- Game State Variables ---
let gameActive = false;
let score = 0;
let timeLeft = 30;
let timerId = null;
let currentStar = { x: 320, y: 240, r: 18 };
let pointer = { x: 320, y: 240 };
let controlMode = "webcam"; // webcam or mouse

// Stats
let dbHighScore = <?php echo $high_score; ?>;

// MediaPipe variables
let camera = null;
let hands = null;
let cameraRunning = false;

// Elements
const videoElement = document.getElementById('webcam');
const canvasElement = document.getElementById('game-canvas');
const ctx = canvasElement.getContext('2d');
const btnStart = document.getElementById('btn-start');
const btnRestart = document.getElementById('btn-restart');
const controlModeSelect = document.getElementById('control-mode');
const displayTimer = document.getElementById('display-timer');
const displayCurrentScore = document.getElementById('display-current-score');
const displayHighScore = document.getElementById('display-high-score');
const cameraStatusText = document.getElementById('camera-status');
const modeDesc = document.getElementById('mode-desc');

// --- Web Audio API Synth (Retro gaming beep beep!) ---
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
function playScoreSound() {
    try {
        const osc = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();
        osc.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        
        osc.type = "sine";
        osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
        osc.frequency.setValueAtTime(880.00, audioCtx.currentTime + 0.08); // A5
        
        gainNode.gain.setValueAtTime(0.15, audioCtx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.2);
        
        osc.start();
        osc.stop(audioCtx.currentTime + 0.2);
    } catch(e) {
        console.log("Audio syntax error or blocked:", e);
    }
}

function playGameOverSound(isNewRecord) {
    try {
        const osc = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();
        osc.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        
        if (isNewRecord) {
            // Victory sound
            osc.type = "sawtooth";
            osc.frequency.setValueAtTime(523.25, audioCtx.currentTime); // C5
            osc.frequency.setValueAtTime(659.25, audioCtx.currentTime + 0.1); // E5
            osc.frequency.setValueAtTime(783.99, audioCtx.currentTime + 0.2); // G5
            osc.frequency.setValueAtTime(1046.50, audioCtx.currentTime + 0.3); // C6
            gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.5);
            osc.start();
            osc.stop(audioCtx.currentTime + 0.5);
        } else {
            // Normal game over
            osc.type = "triangle";
            osc.frequency.setValueAtTime(392.00, audioCtx.currentTime); // G4
            osc.frequency.setValueAtTime(293.66, audioCtx.currentTime + 0.15); // D4
            gainNode.gain.setValueAtTime(0.15, audioCtx.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.4);
            osc.start();
            osc.stop(audioCtx.currentTime + 0.4);
        }
    } catch(e) {}
}

// --- Star Spawner ---
function spawnStar() {
    currentStar.x = Math.floor(Math.random() * (canvasElement.width - 60)) + 30;
    currentStar.y = Math.floor(Math.random() * (canvasElement.height - 60)) + 30;
}

// --- Input Mode Toggle ---
controlModeSelect.addEventListener('change', (e) => {
    controlMode = e.target.value;
    if (controlMode === "mouse") {
        modeDesc.innerHTML = "* ใช้เมาส์เลื่อนพอยต์เตอร์กลมสีแดงเลื่อนไปแตะเพื่อเก็บดวงดาวสะสมแต้ม";
        stopCamera();
    } else {
        modeDesc.innerHTML = "* ใช้กล้องเพื่อตรวจจับความเคลื่อนไหวข้อมือเพื่อควบคุมพอยต์เตอร์กลมสีแดงเลื่อนไปเก็บดวงดาวบนจอ";
        if (gameActive) {
            initCamera();
        }
    }
});

// --- Mouse fallback listener ---
canvasElement.addEventListener('mousemove', (e) => {
    if (controlMode === "mouse") {
        const rect = canvasElement.getBoundingClientRect();
        pointer.x = (e.clientX - rect.left) / rect.width * canvasElement.width;
        pointer.y = (e.clientY - rect.top) / rect.height * canvasElement.height;
    }
});

canvasElement.addEventListener('touchmove', (e) => {
    if (controlMode === "mouse" && e.touches.length > 0) {
        e.preventDefault();
        const rect = canvasElement.getBoundingClientRect();
        pointer.x = (e.touches[0].clientX - rect.left) / rect.width * canvasElement.width;
        pointer.y = (e.touches[0].clientY - rect.top) / rect.height * canvasElement.height;
    }
}, { passive: false });

// --- MediaPipe Hands Detection Setup ---
function onHandsResults(results) {
    if (!gameActive || controlMode !== "webcam") return;

    // Clear previous canvas
    ctx.clearRect(0, 0, canvasElement.width, canvasElement.height);

    // If hands detected, map index finger tip (landmark 8) or hand centroid
    if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
        const hand = results.multiHandLandmarks[0];
        // Index finger tip is landmark 8
        const indexTip = hand[8];
        
        // Scale to canvas dimensions with inverted X for mirroring
        pointer.x = (1 - indexTip.x) * canvasElement.width;
        pointer.y = indexTip.y * canvasElement.height;

        // Draw green tracker outline for hand
        ctx.strokeStyle = "rgba(57, 255, 20, 0.4)";
        ctx.lineWidth = 2;
        ctx.beginPath();
        for (let i = 0; i < hand.length; i++) {
            const pt = hand[i];
            const px = (1 - pt.x) * canvasElement.width;
            const py = pt.y * canvasElement.height;
            if (i === 0) ctx.moveTo(px, py);
            else ctx.lineTo(px, py);
        }
        ctx.stroke();
    }
}

function initCamera() {
    if (cameraRunning) return;

    hands = new Hands({
        locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
    });

    hands.setOptions({
        maxNumHands: 1,
        modelComplexity: 1,
        minDetectionConfidence: 0.5,
        minTrackingConfidence: 0.5
    });

    hands.onResults(onHandsResults);

    camera = new Camera(videoElement, {
        onFrame: async () => {
            if (controlMode === "webcam" && gameActive) {
                await hands.send({ image: videoElement });
            }
        },
        width: 640,
        height: 480
    });

    cameraStatusText.innerHTML = "กำลังเปิดกล้องและโหลดระบบ AI...";
    cameraStatusText.className = "mt-3 text-warning fw-bold";

    camera.start()
        .then(() => {
            cameraRunning = true;
            cameraStatusText.innerHTML = "🔴 ระบบกล้องและการจับตรวจเสร็จสมบูรณ์";
            cameraStatusText.className = "mt-3 text-success small";
        })
        .catch(err => {
            console.error(err);
            cameraStatusText.innerHTML = "⚠️ ไม่สามารถเข้าใช้งานกล้องได้ สลับเป็นโหมดเมาส์อัตโนมัติ";
            cameraStatusText.className = "mt-3 text-danger fw-bold";
            controlModeSelect.value = "mouse";
            controlMode = "mouse";
        });
}

function stopCamera() {
    if (camera) {
        try {
            const stream = videoElement.srcObject;
            if (stream) {
                const tracks = stream.getTracks();
                tracks.forEach(track => track.stop());
            }
            videoElement.srcObject = null;
        } catch(e){}
        cameraRunning = false;
        camera = null;
    }
}

// --- Main Game Loop ---
function drawGame() {
    if (!gameActive) return;

    // If mouse control mode, clear canvas manually (camera does it for webcam mode)
    if (controlMode === "mouse") {
        ctx.clearRect(0, 0, canvasElement.width, canvasElement.height);
    }

    // 1. Check Collision between Pointer and Star
    const dist = Math.hypot(pointer.x - currentStar.x, pointer.y - currentStar.y);
    if (dist < currentStar.r + 15) { // Radius collision threshold
        score++;
        displayCurrentScore.innerHTML = score;
        playScoreSound();
        spawnStar();
    }

    // 2. Draw Target Star (Neon Star design)
    ctx.shadowBlur = 15;
    ctx.shadowColor = "rgba(255, 0, 127, 0.8)";
    ctx.fillStyle = varColor('--neon-pink');
    
    // Draw star shape
    ctx.beginPath();
    const spikes = 5;
    const outerRadius = currentStar.r;
    const innerRadius = currentStar.r / 2;
    let cx = currentStar.x;
    let cy = currentStar.y;
    let rot = Math.PI / 2 * 3;
    let x = cx;
    let y = cy;
    let step = Math.PI / spikes;

    for (let i = 0; i < spikes; i++) {
        x = cx + Math.cos(rot) * outerRadius;
        y = cy + Math.sin(rot) * outerRadius;
        ctx.lineTo(x, y);
        rot += step;

        x = cx + Math.cos(rot) * innerRadius;
        y = cy + Math.sin(rot) * innerRadius;
        ctx.lineTo(x, y);
        rot += step;
    }
    ctx.lineTo(cx, cy - outerRadius);
    ctx.closePath();
    ctx.fill();

    // 3. Draw Pointer Ring (Neon blue targeting circle)
    ctx.shadowBlur = 15;
    ctx.shadowColor = "rgba(0, 240, 255, 0.8)";
    ctx.strokeStyle = varColor('--neon-blue');
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(pointer.x, pointer.y, 15, 0, Math.PI * 2);
    ctx.stroke();

    // Inner pointer dot
    ctx.fillStyle = varColor('--neon-blue');
    ctx.beginPath();
    ctx.arc(pointer.x, pointer.y, 4, 0, Math.PI * 2);
    ctx.fill();

    // Reset shadow
    ctx.shadowBlur = 0;

    // Continue Loop
    requestAnimationFrame(drawGame);
}

function varColor(cssVar) {
    return getComputedStyle(document.documentElement).getPropertyValue(cssVar).trim();
}

// --- Start Game Event ---
btnStart.addEventListener('click', () => {
    // Resume AudioContext for browsers restrictions
    if (audioCtx.state === 'suspended') {
        audioCtx.resume();
    }

    score = 0;
    timeLeft = 30;
    gameActive = true;
    displayCurrentScore.innerHTML = "0";
    displayTimer.innerHTML = "30s";
    btnStart.disabled = true;
    btnRestart.classList.add('d-none');

    spawnStar();

    if (controlMode === "webcam") {
        initCamera();
    }

    // Start Timer Interval
    timerId = setInterval(() => {
        timeLeft--;
        displayTimer.innerHTML = timeLeft + "s";

        if (timeLeft <= 0) {
            endGame();
        }
    }, 1000);

    // Start Draw Loop
    drawGame();
});

// --- End Game & Update Score ---
function endGame() {
    gameActive = false;
    clearInterval(timerId);
    
    // Clear Canvas
    ctx.clearRect(0, 0, canvasElement.width, canvasElement.height);

    // Is new High Score?
    const isNewRecord = score > dbHighScore;
    playGameOverSound(isNewRecord);

    if (isNewRecord) {
        dbHighScore = score;
        displayHighScore.innerHTML = dbHighScore;
        alert(`🎮 หมดเวลา!\n🎉 ยอดเยี่ยมมาก! คุณทำสถิติสูงสุดใหม่ได้: ${score} คะแนน`);
    } else {
        alert(`🎮 หมดเวลา!\nคุณได้รับ ${score} คะแนน (คะแนนสูงสุดเดิม: ${dbHighScore} คะแนน)`);
    }

    // Send score to server via AJAX (update_score.php)
    updateScoreOnServer(score);

    btnStart.disabled = false;
    btnStart.innerHTML = "PLAY AGAIN";
}

function updateScoreOnServer(scoreVal) {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "update_score.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onload = function() {
        if (this.status === 200) {
            try {
                const response = JSON.parse(this.responseText);
                if (response.success && response.new_record) {
                    console.log("High score updated on database!");
                }
            } catch(e) {
                console.error("Failed to parse JSON response:", e);
            }
        }
    };
    xhr.send("score=" + encodeURIComponent(scoreVal));
}
</script>

<!-- Bootstrap 5 Bundle JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
