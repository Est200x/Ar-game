<?php
// update_score.php - AJAX score updater
require_once 'config.php';

// Set response header to JSON
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['score'])) {
    $score = filter_var($_POST['score'], FILTER_VALIDATE_INT);
    $user_id = $_SESSION['user_id'];

    if ($score !== false && $score >= 0) {
        try {
            // Get current high score
            $stmt = $pdo->prepare("SELECT high_score FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch();

            if ($user) {
                $current_high = $user['high_score'];
                $new_record = false;

                if ($score > $current_high) {
                    // Update database
                    $update = $pdo->prepare("UPDATE users SET high_score = ? WHERE id = ?");
                    $update->execute([$score, $user_id]);
                    
                    // Update session
                    $_SESSION['high_score'] = $score;
                    $current_high = $score;
                    $new_record = true;
                }

                echo json_encode([
                    'success' => true,
                    'new_record' => $new_record,
                    'high_score' => $current_high
                ]);
                exit();
            } else {
                echo json_encode(['success' => false, 'message' => 'User not found']);
                exit();
            }
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
            exit();
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid score value']);
        exit();
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}
?>
