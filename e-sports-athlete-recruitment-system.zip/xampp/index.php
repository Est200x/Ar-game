<?php
// index.php - Login & Portal Information
require_once 'config.php';

// If already logged in, redirect to game
if (isset($_SESSION['user_id'])) {
    header("Location: game.php");
    exit();
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    if (!empty($username) && !empty($password)) {
        try {
            $stmt = $pdo->prepare("SELECT id, username, password, name, high_score FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                // Set Session variables
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['name'] = $user['name'];
                $_SESSION['high_score'] = $user['high_score'];

                header("Location: game.php");
                exit();
            } else {
                $error = "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง";
            }
        } catch (PDOException $e) {
            $error = "เกิดข้อผิดพลาดของระบบ: " . $e->getMessage();
        }
    } else {
        $error = "กรุณากรอกข้อมูลให้ครบถ้วน";
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Sports Recruitment | ระบบรับสมัครนักกีฬาอีสปอร์ต</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts: Orbitron & Prompt -->
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Prompt:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-dark: #0a0a16;
            --card-bg: rgba(15, 15, 35, 0.75);
            --neon-blue: #00f0ff;
            --neon-pink: #ff007f;
            --text-light: #e2e8f0;
        }

        body {
            background-color: var(--bg-dark);
            background-image: 
                radial-gradient(at 10% 20%, rgba(0, 240, 255, 0.1) 0px, transparent 50%),
                radial-gradient(at 90% 80%, rgba(255, 0, 127, 0.15) 0px, transparent 50%);
            color: var(--text-light);
            font-family: 'Prompt', sans-serif;
            min-height: 100vh;
            overflow-x: hidden;
        }

        .heading-esports {
            font-family: 'Orbitron', sans-serif;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 2px;
            text-shadow: 0 0 10px rgba(0, 240, 255, 0.6), 0 0 20px rgba(0, 240, 255, 0.3);
            color: var(--neon-blue);
        }

        .text-pink {
            color: var(--neon-pink);
            text-shadow: 0 0 10px rgba(255, 0, 127, 0.6);
        }

        .neon-card {
            background: var(--card-bg);
            border: 1px solid rgba(0, 240, 255, 0.2);
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.37);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            border-radius: 15px;
            transition: all 0.3s ease;
        }

        .neon-card:hover {
            border-color: rgba(0, 240, 255, 0.5);
            box-shadow: 0 0 20px rgba(0, 240, 255, 0.2);
        }

        .btn-neon-blue {
            background: transparent;
            border: 2px solid var(--neon-blue);
            color: var(--neon-blue);
            font-family: 'Orbitron', sans-serif;
            font-weight: 700;
            letter-spacing: 1px;
            transition: all 0.3s ease;
            box-shadow: 0 0 10px rgba(0, 240, 255, 0.1);
        }

        .btn-neon-blue:hover {
            background: var(--neon-blue);
            color: var(--bg-dark);
            box-shadow: 0 0 15px var(--neon-blue);
        }

        .btn-neon-pink {
            background: transparent;
            border: 2px solid var(--neon-pink);
            color: var(--neon-pink);
            font-family: 'Orbitron', sans-serif;
            font-weight: 700;
            letter-spacing: 1px;
            transition: all 0.3s ease;
            box-shadow: 0 0 10px rgba(255, 0, 127, 0.1);
        }

        .btn-neon-pink:hover {
            background: var(--neon-pink);
            color: #fff;
            box-shadow: 0 0 15px var(--neon-pink);
        }

        .form-control {
            background-color: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: #fff;
            border-radius: 8px;
        }

        .form-control:focus {
            background-color: rgba(255, 255, 255, 0.08);
            border-color: var(--neon-blue);
            color: #fff;
            box-shadow: 0 0 10px rgba(0, 240, 255, 0.25);
        }

        .badge-pro {
            background: linear-gradient(135deg, var(--neon-blue), var(--neon-pink));
            color: var(--bg-dark);
            font-family: 'Orbitron', sans-serif;
            font-weight: 900;
        }
    </style>
</head>
<body>

<div class="container py-5">
    <!-- Header Section -->
    <div class="text-center mb-5">
        <span class="badge badge-pro px-3 py-2 rounded-pill mb-2">E-SPORTS ATHLETE SELECTION</span>
        <h1 class="heading-esports display-4">NEXT-GEN RECRUITMENT</h1>
        <p class="lead text-muted">ระบบทดสอบและคัดเลือกนักกีฬาอีสปอร์ตระดับมืออาชีพ</p>
    </div>

    <div class="row g-4 align-items-center justify-content-center">
        <!-- Info Column -->
        <div class="col-lg-6">
            <div class="neon-card p-4 h-100">
                <h3 class="text-pink mb-4" style="font-family: 'Orbitron', sans-serif; font-weight:700;">PRO-TESTING PORTAL</h3>
                <p>ยินดีต้อนรับสู่ระบบทดสอบปฏิกิริยาและความว่องไวของร่างกายแบบอัจฉริยะ โครงการคัดเลือกเยาวชนสู่ทำเนียบนักกีฬาระดับประเทศ</p>
                
                <h5 class="mt-4 mb-3 text-info">กติกาการทดสอบ:</h5>
                <ul class="list-unstyled">
                    <li class="mb-2">⚡ <strong>มินิเกมตรวจจับภาพมือ (AR Hand Game):</strong> ใช้ระบบ AI ตรวจจับมือผ่านกล้อง Webcam</li>
                    <li class="mb-2">⭐ <strong>เก็บคะแนนดาว:</strong> ขยับมือสัมผัสดาวที่สุ่มปรากฏขึ้นมาบนหน้าจอ</li>
                    <li class="mb-2">⏱️ <strong>จำกัดเวลา 30 วินาที:</strong> ทำความเร็วเพื่อช่วงชิงอันดับสูงสุด</li>
                    <li class="mb-2">🏆 <strong>บันทึกสถิติ:</strong> คะแนนสูงสุดของคุณจะถูกบันทึกลงฐานข้อมูลเพื่อประเมินความสามารถ</li>
                </ul>

                <div class="mt-4 border-top border-secondary pt-3">
                    <p class="text-muted small">หมายเหตุ: จำเป็นต้องได้รับการอนุญาตใช้งานกล้อง Webcam สำหรับใช้ระบบตรวจจับการเคลื่อนไหวของมือ</p>
                </div>
            </div>
        </div>

        <!-- Login Column -->
        <div class="col-lg-5 col-md-8">
            <div class="neon-card p-4">
                <h3 class="heading-esports text-center mb-4" style="font-size: 1.8rem;">SECURE LOGIN</h3>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger bg-danger bg-opacity-25 border-danger text-danger mb-3" role="alert">
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="index.php">
                    <div class="mb-3">
                        <label for="username" class="form-label text-info">ชื่อผู้ใช้ (Username)</label>
                        <input type="text" class="form-control" id="username" name="username" placeholder="กรอก Username ของคุณ" required autocomplete="username">
                    </div>
                    <div class="mb-4">
                        <label for="password" class="form-label text-info">รหัสผ่าน (Password)</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="กรอกรหัสผ่าน" required autocomplete="current-password">
                    </div>
                    
                    <button type="submit" class="btn btn-neon-blue w-full py-2.5 mb-3 w-100">LOG IN NOW</button>
                </form>

                <div class="text-center mt-3">
                    <p class="text-muted mb-0">ยังไม่มีบัญชีสมาชิก?</p>
                    <a href="register.php" class="btn btn-neon-pink btn-sm mt-2 px-4">สมัครสมาชิกใหม่ (REGISTER)</a>
                </div>
            </div>
        </div>
    </div>
</div>

<footer class="text-center py-4 mt-5 border-top border-secondary border-opacity-25">
    <p class="text-muted small mb-0">© 2026 E-Sports Selection Portal. All Rights Reserved.</p>
</footer>

<!-- Bootstrap 5 Bundle JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
