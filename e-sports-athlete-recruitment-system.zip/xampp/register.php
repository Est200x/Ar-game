<?php
// register.php - User Registration
require_once 'config.php';

// If already logged in, redirect to game
if (isset($_SESSION['user_id'])) {
    header("Location: game.php");
    exit();
}

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    if (!empty($name) && !empty($email) && !empty($username) && !empty($password)) {
        try {
            // Check if username already exists
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
            $stmt->execute([$username]);
            if ($stmt->fetch()) {
                $error = "ชื่อผู้ใช้นี้ถูกใช้งานแล้ว กรุณาเลือกชื่อผู้ใช้อื่น";
            } else {
                // Hash Password
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                // Insert into Database
                $insert = $pdo->prepare("INSERT INTO users (username, password, name, email) VALUES (?, ?, ?, ?)");
                if ($insert->execute([$username, $hashed_password, $name, $email])) {
                    $success = "สมัครสมาชิกสำเร็จ! กำลังนำคุณกลับไปหน้าแรกเพื่อล็อกอิน...";
                    // Output JavaScript to redirect after 2 seconds
                    header("refresh:2; url=index.php");
                } else {
                    $error = "เกิดข้อผิดพลาดในการลงทะเบียน";
                }
            }
        } catch (PDOException $e) {
            $error = "เกิดข้อผิดพลาดของระบบ: " . $e->getMessage();
        }
    } else {
        $error = "กรุณากรอกข้อมูลให้ครบถ้วน";
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | สมัครสมาชิกระบบรับสมัครนักกีฬา</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts: Orbitron & Prompt -->
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Prompt:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-dark: #0a0a16;
            --card-bg: rgba(15, 15, 35, 0.75);
            --neon-blue: #00f0ff;
            --neon-pink: #ff007f;
            --text-light: #e2e8f0;
        }

        body {
            background-color: var(--bg-dark);
            background-image: 
                radial-gradient(at 10% 20%, rgba(0, 240, 255, 0.1) 0px, transparent 50%),
                radial-gradient(at 90% 80%, rgba(255, 0, 127, 0.15) 0px, transparent 50%);
            color: var(--text-light);
            font-family: 'Prompt', sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px 0;
        }

        .heading-esports {
            font-family: 'Orbitron', sans-serif;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 2px;
            text-shadow: 0 0 10px rgba(255, 0, 127, 0.6), 0 0 20px rgba(255, 0, 127, 0.3);
            color: var(--neon-pink);
        }

        .neon-card {
            background: var(--card-bg);
            border: 1px solid rgba(255, 0, 127, 0.2);
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.37);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            border-radius: 15px;
            transition: all 0.3s ease;
            max-width: 500px;
            width: 100%;
        }

        .neon-card:hover {
            border-color: rgba(255, 0, 127, 0.5);
            box-shadow: 0 0 20px rgba(255, 0, 127, 0.2);
        }

        .btn-neon-pink {
            background: transparent;
            border: 2px solid var(--neon-pink);
            color: var(--neon-pink);
            font-family: 'Orbitron', sans-serif;
            font-weight: 700;
            letter-spacing: 1px;
            transition: all 0.3s ease;
            box-shadow: 0 0 10px rgba(255, 0, 127, 0.1);
        }

        .btn-neon-pink:hover {
            background: var(--neon-pink);
            color: #fff;
            box-shadow: 0 0 15px var(--neon-pink);
        }

        .btn-link-blue {
            color: var(--neon-blue);
            text-decoration: none;
            font-weight: 600;
            transition: all 0.2s ease;
        }

        .btn-link-blue:hover {
            text-shadow: 0 0 8px rgba(0, 240, 255, 0.6);
            color: #fff;
        }

        .form-control {
            background-color: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: #fff;
            border-radius: 8px;
        }

        .form-control:focus {
            background-color: rgba(255, 255, 255, 0.08);
            border-color: var(--neon-pink);
            color: #fff;
            box-shadow: 0 0 10px rgba(255, 0, 127, 0.25);
        }
    </style>
</head>
<body>

<div class="neon-card p-4 mx-3">
    <h3 class="heading-esports text-center mb-4">REGISTER</h3>
    
    <?php if (!empty($error)): ?>
        <div class="alert alert-danger bg-danger bg-opacity-25 border-danger text-danger mb-3" role="alert">
            <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($success)): ?>
        <div class="alert alert-success bg-success bg-opacity-25 border-success text-success mb-3" role="alert">
            <?php echo htmlspecialchars($success); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="register.php">
        <div class="mb-3">
            <label for="name" class="form-label text-info">ชื่อ-นามสกุล (Full Name)</label>
            <input type="text" class="form-control" id="name" name="name" placeholder="กรอกชื่อ-นามสกุลจริง" required>
        </div>
        
        <div class="mb-3">
            <label for="email" class="form-label text-info">อีเมล (Email)</label>
            <input type="email" class="form-control" id="email" name="email" placeholder="example@domain.com" required>
        </div>

        <div class="mb-3">
            <label for="username" class="form-label text-info">ตั้งชื่อผู้ใช้ (Username)</label>
            <input type="text" class="form-control" id="username" name="username" placeholder="ภาษาอังกฤษหรือตัวเลขอย่างน้อย 4 ตัวอักษร" required autocomplete="username">
        </div>

        <div class="mb-4">
            <label for="password" class="form-label text-info">รหัสผ่าน (Password)</label>
            <input type="password" class="form-control" id="password" name="password" placeholder="ตั้งรหัสผ่านสำหรับเข้าสู่ระบบ" required autocomplete="new-password">
        </div>
        
        <button type="submit" class="btn btn-neon-pink w-100 py-2.5 mb-3">CREATE ACCOUNT</button>
    </form>

    <div class="text-center mt-3">
        <p class="text-muted mb-0">มีบัญชีผู้ใช้อยู่แล้ว?</p>
        <a href="index.php" class="btn-link-blue">เข้าสู่ระบบ (LOGIN)</a>
    </div>
</div>

<!-- Bootstrap 5 Bundle JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
