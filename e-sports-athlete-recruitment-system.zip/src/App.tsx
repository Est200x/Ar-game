import React, { useState, useEffect } from "react";
import { User, LeaderboardEntry, PHPFiles } from "./types";
import { Header } from "./components/Header";
import { GameArea } from "./components/GameArea";
import { Leaderboard } from "./components/Leaderboard";
import { CodeViewer } from "./components/CodeViewer";
import { Trophy, Shield, Rocket, Target, Send, KeyRound, UserPlus, FileCode } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [view, setView] = useState<"home" | "register" | "game">("home");
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [phpCodes, setPhpCodes] = useState<PHPFiles | null>(null);
  const [showCodePanel, setShowCodePanel] = useState<boolean>(true);

  // Form states
  const [loginUsername, setLoginUsername] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [loginError, setLoginError] = useState("");

  const [regName, setRegName] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regUsername, setRegUsername] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [regError, setRegError] = useState("");
  const [regSuccess, setRegSuccess] = useState("");

  // Loading states
  const [loadingSession, setLoadingSession] = useState(true);
  const [loadingLeaderboard, setLoadingLeaderboard] = useState(false);
  const [loadingPhp, setLoadingPhp] = useState(false);
  const [phpError, setPhpError] = useState("");

  // Check active session on mount
  useEffect(() => {
    fetchSession();
    fetchLeaderboard();
    fetchPhpCodes();
  }, []);

  const fetchSession = async () => {
    setLoadingSession(true);
    try {
      const res = await fetch("/api/current-user");
      const data = await res.json();
      if (data.user) {
        setCurrentUser(data.user);
        setView("game");
      } else {
        setCurrentUser(null);
        setView("home");
      }
    } catch (e) {
      console.error("Session fetch failed", e);
    } finally {
      setLoadingSession(false);
    }
  };

  const fetchLeaderboard = async () => {
    setLoadingLeaderboard(true);
    try {
      const res = await fetch("/api/leaderboard");
      const data = await res.json();
      if (data.success) {
        setLeaderboard(data.leaderboard);
      }
    } catch (e) {
      console.error("Leaderboard fetch failed", e);
    } finally {
      setLoadingLeaderboard(false);
    }
  };

  const fetchPhpCodes = async () => {
    setLoadingPhp(true);
    try {
      const res = await fetch("/api/php-source");
      const data = await res.json();
      if (data.success) {
        setPhpCodes(data.files);
      } else {
        setPhpError(data.message || "Failed to load");
      }
    } catch (e: any) {
      setPhpError(e.message || "Failed to read PHP files");
    } finally {
      setLoadingPhp(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");

    if (!loginUsername || !loginPassword) {
      setLoginError("กรุณากรอกข้อมูลให้ครบถ้วน");
      return;
    }

    try {
      const res = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: loginUsername, password: loginPassword })
      });
      const data = await res.json();

      if (res.ok && data.success) {
        setCurrentUser(data.user);
        setView("game");
        setLoginUsername("");
        setLoginPassword("");
        fetchLeaderboard(); // Update rankings
      } else {
        setLoginError(data.message || "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง");
      }
    } catch (err) {
      setLoginError("ไม่สามารถเข้าสู่ระบบในขณะนี้ได้");
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setRegError("");
    setRegSuccess("");

    if (!regName || !regEmail || !regUsername || !regPassword) {
      setRegError("กรุณากรอกข้อมูลให้ครบถ้วน");
      return;
    }

    try {
      const res = await fetch("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: regName,
          email: regEmail,
          username: regUsername,
          password: regPassword
        })
      });
      const data = await res.json();

      if (res.ok && data.success) {
        setRegSuccess("สมัครสมาชิกสำเร็จ! กรุณาล็อกอินเพื่อเริ่มการทดสอบ");
        setRegName("");
        setRegEmail("");
        setRegUsername("");
        setRegPassword("");
        fetchLeaderboard(); // Refresh list

        // Navigate to login after 2 seconds
        setTimeout(() => {
          setView("home");
          setRegSuccess("");
        }, 1800);
      } else {
        setRegError(data.message || "สมัครสมาชิกไม่สำเร็จ");
      }
    } catch (err) {
      setRegError("เกิดข้อผิดพลาดในการลงทะเบียน");
    }
  };

  const handleLogout = async () => {
    try {
      await fetch("/api/logout", { method: "POST" });
      setCurrentUser(null);
      setView("home");
    } catch (e) {
      console.error("Logout failed", e);
    }
  };

  const handleScoreUpdate = (newHighScore: number) => {
    if (currentUser) {
      setCurrentUser({ ...currentUser, high_score: newHighScore });
      fetchLeaderboard(); // Refresh rankings instantly
    }
  };

  if (loadingSession) {
    return (
      <div className="min-h-screen bg-gaming-dark flex flex-col items-center justify-center text-white font-sans">
        <div className="relative">
          <div className="absolute -inset-4 rounded-full bg-neon-blue opacity-50 blur-xl animate-pulse" />
          <div className="relative w-16 h-16 border-t-4 border-b-4 border-neon-blue rounded-full animate-spin" />
        </div>
        <p className="mt-6 font-orbitron font-bold tracking-widest text-sm text-neon-blue animate-pulse">
          LOADING PORTAL SYSTEM...
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gaming-dark text-white font-sans flex flex-col selection:bg-neon-pink selection:text-white">
      {/* High tech background glow effect */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute top-[10%] left-[5%] w-[40vw] h-[40vw] rounded-full bg-neon-blue/5 blur-[120px]" />
        <div className="absolute bottom-[10%] right-[5%] w-[40vw] h-[40vw] rounded-full bg-neon-pink/5 blur-[120px]" />
      </div>

      {/* Header */}
      <Header
        currentUser={currentUser}
        onLogout={handleLogout}
        showCodePanel={showCodePanel}
        setShowCodePanel={setShowCodePanel}
      />

      {/* Main Content Layout */}
      <main className="flex-grow max-w-7xl w-full mx-auto p-4 md:p-6 lg:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8 z-10 relative">
        
        {/* Left Column (Main App / Content depending on view) */}
        <div className={`${showCodePanel ? "lg:col-span-8" : "lg:col-span-12"} flex flex-col gap-8 transition-all duration-300`}>
          
          <AnimatePresence mode="wait">
            {view === "home" && (
              <motion.div
                key="home"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                className="grid grid-cols-1 md:grid-cols-12 gap-6"
              >
                {/* Recruitment Information Details */}
                <div className="md:col-span-7 glass-card p-6 rounded-xl flex flex-col gap-6">
                  <div>
                    <span className="text-[10px] font-orbitron font-black bg-neon-blue/15 text-neon-blue px-3 py-1 rounded-full border border-neon-blue/20">
                      OFFICIAL RECRUITMENT CAMPAIGN
                    </span>
                    <h2 className="text-2xl md:text-3xl font-orbitron font-black tracking-tight text-white mt-3 leading-tight uppercase">
                      โครงการคัดเลือกเยาวชน <br />
                      <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-blue to-neon-pink neon-glow-blue">
                        นักกีฬาอีสปอร์ตอาชีพ
                      </span>
                    </h2>
                    <p className="text-xs text-gray-400 mt-2 leading-relaxed">
                      ร่วมเป็นหนึ่งในทีมพัฒนาศักยภาพผู้เล่นระดับแนวหน้าของประเทศ 
                      ผ่านระบบคัดกรองความว่องไว ปฏิกิริยาตอบสนองทางข้อมือและสมองอัจฉริยะ (AR Reflex Test)
                    </p>
                  </div>

                  {/* Core Features list */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="p-4 rounded-lg bg-white/5 border border-white/5 hover:border-neon-blue/30 transition-colors">
                      <Target className="w-6 h-6 text-neon-blue mb-2" />
                      <h4 className="text-xs font-bold text-white uppercase font-orbitron">AR Hand Tracking</h4>
                      <p className="text-[11px] text-gray-400 mt-1 leading-snug">
                        ใช้โมเดลตรวจจับปัญญาประดิษฐ์ตรวจจับวิถีข้อมือของคุณผ่านเลนส์กล้องเว็บแคมแบบเสมือนจริง
                      </p>
                    </div>

                    <div className="p-4 rounded-lg bg-white/5 border border-white/5 hover:border-neon-pink/30 transition-colors">
                      <Trophy className="w-6 h-6 text-neon-pink mb-2" />
                      <h4 className="text-xs font-bold text-white uppercase font-orbitron">Interactive Stars</h4>
                      <p className="text-[11px] text-gray-400 mt-1 leading-snug">
                        ทดสอบการชิงจังหวะ แตะเก็บดาวให้ครบและทำคะแนนสูงสุดให้ได้ภายในเวลาจำกัด 30 วินาที
                      </p>
                    </div>

                    <div className="p-4 rounded-lg bg-white/5 border border-white/5 hover:border-neon-green/30 transition-colors">
                      <Shield className="w-6 h-6 text-neon-green mb-2" />
                      <h4 className="text-xs font-bold text-white uppercase font-orbitron">Secure DB Sync</h4>
                      <p className="text-[11px] text-gray-400 mt-1 leading-snug">
                        สถิติคะแนนบันทึกลงฐานข้อมูลอย่างปลอดภัยเพื่อใช้ประเมินและคัดกรองในรอบถัดไป
                      </p>
                    </div>

                    <div className="p-4 rounded-lg bg-white/5 border border-white/5 hover:border-neon-blue/30 transition-colors">
                      <Rocket className="w-6 h-6 text-neon-blue mb-2" />
                      <h4 className="text-xs font-bold text-white uppercase font-orbitron">Pro Sandbox</h4>
                      <p className="text-[11px] text-gray-400 mt-1 leading-snug">
                        มีเมาส์พอยเตอร์และสัมผัสเป็นโหมดสำรอง (Fallback) ให้คัดเลือกแม้เบราว์เซอร์กล้องถูกล็อก
                      </p>
                    </div>
                  </div>

                  <div className="bg-white/5 border-l-2 border-neon-blue p-3 text-[11px] text-gray-400">
                    * ข้อแนะนำ: เพื่อประสบการณ์การทดสอบที่ดีที่สุด ควรนั่งในห้องที่มีแสงสว่างเพียงพอและอนุญาตให้ระบบเข้าใช้กล้อง Webcam เมื่อเปิดโหมด AR
                  </div>
                </div>

                {/* Login Form */}
                <div className="md:col-span-5">
                  <div className="glass-card p-6 rounded-xl flex flex-col gap-5 relative overflow-hidden">
                    {/* Glowing Accent */}
                    <div className="absolute top-0 right-0 w-24 h-24 bg-neon-blue/10 rounded-full blur-xl pointer-events-none" />

                    <div className="text-center">
                      <h3 className="font-orbitron font-black text-xl text-neon-blue uppercase">SECURE LOGIN</h3>
                      <p className="text-[11px] text-gray-400 mt-1">กรอกข้อมูลผู้ใช้งานเพื่อเข้าห้องทดสอบเกม</p>
                    </div>

                    {loginError && (
                      <div className="bg-red-500/10 border border-red-500/20 text-red-400 px-3 py-2 rounded text-xs">
                        {loginError}
                      </div>
                    )}

                    <form onSubmit={handleLogin} className="flex flex-col gap-4">
                      <div>
                        <label className="text-[11px] font-bold text-gray-400 block mb-1">ชื่อผู้ใช้งาน (Username)</label>
                        <div className="relative">
                          <Send className="w-4 h-4 text-neon-blue/50 absolute left-3 top-3" />
                          <input
                            type="text"
                            required
                            placeholder="Username ของคุณ"
                            value={loginUsername}
                            onChange={(e) => setLoginUsername(e.target.value)}
                            className="w-full bg-white/5 border border-white/10 focus:border-neon-blue/50 focus:ring-1 focus:ring-neon-blue/20 rounded px-10 py-2.5 text-xs text-white outline-none transition-all"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-[11px] font-bold text-gray-400 block mb-1">รหัสผ่าน (Password)</label>
                        <div className="relative">
                          <KeyRound className="w-4 h-4 text-neon-blue/50 absolute left-3 top-3" />
                          <input
                            type="password"
                            required
                            placeholder="••••••••"
                            value={loginPassword}
                            onChange={(e) => setLoginPassword(e.target.value)}
                            className="w-full bg-white/5 border border-white/10 focus:border-neon-blue/50 focus:ring-1 focus:ring-neon-blue/20 rounded px-10 py-2.5 text-xs text-white outline-none transition-all"
                          />
                        </div>
                      </div>

                      <button
                        type="submit"
                        className="w-full bg-neon-blue text-black font-orbitron font-bold text-xs py-2.5 rounded hover:opacity-95 shadow-[0_0_12px_rgba(0,240,255,0.2)] transition-all uppercase tracking-wider mt-2"
                      >
                        LOG IN NOW
                      </button>
                    </form>

                    <div className="text-center pt-3 border-t border-white/5">
                      <p className="text-xs text-gray-400">ยังไม่ได้ลงทะเบียนผู้สมัคร?</p>
                      <button
                        onClick={() => setView("register")}
                        className="mt-2 text-neon-pink hover:text-white font-orbitron font-black text-xs flex items-center justify-center gap-1.5 mx-auto transition-colors"
                      >
                        <UserPlus className="w-4 h-4" />
                        <span>สมัครสมาชิกที่นี่ (REGISTER)</span>
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {view === "register" && (
              <motion.div
                key="register"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                className="max-w-md mx-auto w-full glass-card p-6 rounded-xl flex flex-col gap-5 relative"
              >
                {/* Glowing Pink Accent */}
                <div className="absolute top-0 right-0 w-24 h-24 bg-neon-pink/10 rounded-full blur-xl pointer-events-none" />

                <div className="text-center">
                  <h3 className="font-orbitron font-black text-xl text-neon-pink uppercase">REGISTER PORTAL</h3>
                  <p className="text-[11px] text-gray-400 mt-1">สร้างบัญชีผู้สมัครสอบเพื่อเก็บแต้มความว่องไวของคุณ</p>
                </div>

                {regError && (
                  <div className="bg-red-500/10 border border-red-500/20 text-red-400 px-3 py-2 rounded text-xs">
                    {regError}
                  </div>
                )}

                {regSuccess && (
                  <div className="bg-green-500/10 border border-green-500/20 text-neon-green px-3 py-2 rounded text-xs">
                    {regSuccess}
                  </div>
                )}

                <form onSubmit={handleRegister} className="flex flex-col gap-4">
                  <div>
                    <label className="text-[11px] font-bold text-gray-400 block mb-1">ชื่อ-นามสกุลจริง (Full Name)</label>
                    <input
                      type="text"
                      required
                      placeholder="กรอกชื่อและนามสกุลของคุณ"
                      value={regName}
                      onChange={(e) => setRegName(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 focus:border-neon-pink/50 focus:ring-1 focus:ring-neon-pink/20 rounded px-4 py-2.5 text-xs text-white outline-none transition-all"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-gray-400 block mb-1">อีเมล (Email Address)</label>
                    <input
                      type="email"
                      required
                      placeholder="example@esports.com"
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 focus:border-neon-pink/50 focus:ring-1 focus:ring-neon-pink/20 rounded px-4 py-2.5 text-xs text-white outline-none transition-all"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-gray-400 block mb-1">ชื่อผู้ใช้ (Username)</label>
                    <input
                      type="text"
                      required
                      placeholder="ความยาวอย่างน้อย 4 ตัวอักษร"
                      value={regUsername}
                      onChange={(e) => setRegUsername(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 focus:border-neon-pink/50 focus:ring-1 focus:ring-neon-pink/20 rounded px-4 py-2.5 text-xs text-white outline-none transition-all"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-gray-400 block mb-1">รหัสผ่าน (Password)</label>
                    <input
                      type="password"
                      required
                      placeholder="รหัสผ่านเข้าสู่ระบบ"
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 focus:border-neon-pink/50 focus:ring-1 focus:ring-neon-pink/20 rounded px-4 py-2.5 text-xs text-white outline-none transition-all"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-neon-pink text-white font-orbitron font-bold text-xs py-3 rounded hover:opacity-95 shadow-[0_0_12px_rgba(255,0,127,0.2)] transition-all uppercase tracking-wider mt-2"
                  >
                    CREATE ACCOUNT
                  </button>
                </form>

                <div className="text-center pt-3 border-t border-white/5">
                  <p className="text-xs text-gray-400">มีบัญชีผู้สมัครสอบแล้ว?</p>
                  <button
                    onClick={() => setView("home")}
                    className="mt-2 text-neon-blue hover:text-white font-orbitron font-semibold text-xs transition-colors"
                  >
                    กลับไปเข้าสู่ระบบ (LOGIN)
                  </button>
                </div>
              </motion.div>
            )}

            {view === "game" && (
              <motion.div
                key="game"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                className="flex flex-col gap-6"
              >
                <GameArea currentUser={currentUser} onScoreUpdate={handleScoreUpdate} />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Leaderboard and Information Section below main views */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            <div className="md:col-span-6">
              <Leaderboard entries={leaderboard} loading={loadingLeaderboard} />
            </div>

            <div className="md:col-span-6 glass-card p-5 rounded-xl flex flex-col justify-between">
              <div>
                <h4 className="font-orbitron font-bold text-white text-sm border-b border-white/10 pb-2 mb-3 flex items-center gap-2">
                  <Shield className="w-5 h-5 text-neon-blue" />
                  <span>เกี่ยวกับเกณฑ์คัดเลือกและกติกา</span>
                </h4>
                <div className="space-y-3.5 text-xs text-gray-300 leading-relaxed">
                  <p>
                    <strong>🎯 ปฏิกิริยาและความว่องไว:</strong> นักกีฬาอีสปอร์ตระดับโลกต้องการความเร็วการตอบสนองของระบบประสาทสั่งการข้อมือในหลักเสี้ยววินาที (Milliseconds) มินิเกมนี้ออกแบบเพื่อวัดดัชนีเฉลี่ยความเร็วสะสมของคุณ
                  </p>
                  <p>
                    <strong>💡 ความปลอดภัยสูงสุด:</strong> หน้าเว็บสมัครและเกมจำลองนี้พัฒนาขึ้นบนสถาปัตยกรรมระดับอุตสาหกรรม โดยใช้มาตรฐานความปลอดภัยสูงสุด เช่น การทำ Password Hashing (ใน PHP code ใช้ bcrypt) เพื่อป้องกันข้อมูลรั่วไหล
                  </p>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-white/10 text-[10px] text-gray-400">
                หากต้องการนำโปรเจคไปใช้สอบหรือติดตั้งในเครื่องคอมพิวเตอร์ของคุณ กรุณากดปุ่ม <strong className="text-neon-blue font-semibold">"ดูโค้ด PHP/MySQL (XAMPP)"</strong> ที่บาร์บอนเพื่ออ่านไฟล์และดาวน์โหลดคำแนะนำ
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (Dynamic PHP Source Code Panel - visible if showCodePanel is true) */}
        {showCodePanel && (
          <div className="lg:col-span-4 flex flex-col gap-6 animate-slide-in">
            <CodeViewer files={phpCodes} loading={loadingPhp} errorMsg={phpError} />
          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="border-t border-white/10 bg-gaming-dark/60 py-6 px-6 mt-12 text-center text-xs text-gray-500 font-medium">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>© 2026 E-Sports Selection Portal. All Rights Reserved. (ระบบสมัครนักกีฬาอีสปอร์ตและ AR เกม)</p>
          <div className="flex gap-4 font-mono text-[10px]">
            <span className="text-neon-blue">NODE.JS SERVER ON PORT 3000</span>
            <span className="text-gray-600">|</span>
            <span className="text-neon-pink">READY FOR XAMPP (MYSQL)</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
