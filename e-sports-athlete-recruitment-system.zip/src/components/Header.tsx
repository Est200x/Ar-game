import React from "react";
import { User } from "../types";
import { Trophy, LogOut, ShieldAlert, Cpu, Laptop, FileCode } from "lucide-react";

interface HeaderProps {
  currentUser: User | null;
  onLogout: () => void;
  showCodePanel: boolean;
  setShowCodePanel: (show: boolean) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  onLogout,
  showCodePanel,
  setShowCodePanel,
}) => {
  return (
    <header className="border-b border-white/10 bg-gaming-dark/80 backdrop-blur-md sticky top-0 z-50 py-4 px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="absolute -inset-1 rounded bg-gradient-to-r from-neon-blue to-neon-pink opacity-70 blur" />
            <div className="relative bg-black text-neon-blue font-orbitron font-black text-xl px-3 py-1 border border-neon-blue/30 rounded flex items-center gap-2">
              <Cpu className="w-5 h-5 text-neon-blue animate-pulse" />
              <span>PRO-SELECTION</span>
            </div>
          </div>
          <div className="hidden sm:block">
            <h1 className="text-xs font-orbitron text-gray-400 tracking-wider">E-SPORTS PORTAL</h1>
            <p className="text-[10px] text-neon-pink font-semibold">RECRUITMENT SYSTEM v1.0</p>
          </div>
        </div>

        {/* Action Controls & Session */}
        <div className="flex items-center justify-between md:justify-end gap-4">
          <button
            onClick={() => setShowCodePanel(!showCodePanel)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded text-xs font-orbitron font-semibold tracking-wider border transition-all duration-300 ${
              showCodePanel
                ? "bg-neon-blue text-black border-neon-blue shadow-[0_0_10px_rgba(0,240,255,0.4)]"
                : "bg-transparent text-neon-blue border-neon-blue/30 hover:border-neon-blue/80 hover:bg-neon-blue/10"
            }`}
          >
            <FileCode className="w-4 h-4" />
            <span>{showCodePanel ? "ซ่อนโค้ด PHP/MySQL" : "ดูโค้ด PHP/MySQL (XAMPP)"}</span>
          </button>

          {currentUser ? (
            <div className="flex items-center gap-4">
              <div className="hidden md:flex flex-col items-end">
                <span className="text-[10px] text-gray-400">ผู้สมัครทดสอบ</span>
                <span className="text-xs font-semibold text-neon-blue">
                  {currentUser.name} <span className="text-gray-400 text-[10px]">(@{currentUser.username})</span>
                </span>
              </div>
              <div className="flex items-center gap-2 bg-white/5 border border-white/10 px-3 py-1.5 rounded">
                <Trophy className="w-4 h-4 text-amber-400" />
                <div className="text-xs">
                  <span className="text-gray-400">High Score:</span>{" "}
                  <span className="font-orbitron font-bold text-neon-green">{currentUser.high_score}</span>
                </div>
              </div>
              <button
                onClick={onLogout}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-orbitron font-bold text-neon-pink border border-neon-pink/30 hover:bg-neon-pink/10 hover:border-neon-pink hover:shadow-[0_0_10px_rgba(255,0,127,0.3)] transition-all duration-300"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">LOGOUT</span>
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2 bg-neon-pink/10 border border-neon-pink/20 px-3 py-1.5 rounded text-xs text-neon-pink font-semibold">
              <ShieldAlert className="w-4 h-4" />
              <span>กติกา: จำเป็นต้องล็อกอินก่อนเล่นเกม</span>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
