import React, { useState, useEffect, useRef } from "react";
import { User } from "../types";
import { Play, RotateCcw, Video, MousePointer, Info, Volume2, Trophy } from "lucide-react";

interface GameAreaProps {
  currentUser: User | null;
  onScoreUpdate: (newHighScore: number) => void;
}

export const GameArea: React.FC<GameAreaProps> = ({ currentUser, onScoreUpdate }) => {
  const [gameActive, setGameActive] = useState<boolean>(false);
  const [score, setScore] = useState<number>(0);
  const [timeLeft, setTimeLeft] = useState<number>(30);
  const [controlMode, setControlMode] = useState<"webcam" | "mouse">("mouse");
  const [cameraStatus, setCameraStatus] = useState<string>("โหมดเมาส์พร้อมใช้งาน (หรือเลือกกล้องเพื่อเริ่มระบบตรวจจับมือ AR)");
  
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Game tracking state
  const starRef = useRef<{ x: number; y: number; r: number }>({ x: 320, y: 240, r: 18 });
  const pointerRef = useRef<{ x: number; y: number }>({ x: 320, y: 240 });
  const currentScoreRef = useRef<number>(0);
  
  // MediaPipe references
  const handsRef = useRef<any>(null);
  const cameraRef = useRef<any>(null);
  const isCameraIniting = useRef<boolean>(false);

  // Initialize AudioContext lazily
  const getAudioContext = () => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (audioCtxRef.current.state === "suspended") {
      audioCtxRef.current.resume();
    }
    return audioCtxRef.current;
  };

  // Sound Synthesizer
  const playScoreSound = () => {
    try {
      const ctx = getAudioContext();
      const osc = ctx.createOscillator();
      const gainNode = ctx.createGain();
      osc.connect(gainNode);
      gainNode.connect(ctx.destination);
      
      osc.type = "sine";
      osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
      osc.frequency.setValueAtTime(880.00, ctx.currentTime + 0.08); // A5
      
      gainNode.gain.setValueAtTime(0.12, ctx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);
      
      osc.start();
      osc.stop(ctx.currentTime + 0.2);
    } catch (e) {
      console.warn("Audio blocked or not supported:", e);
    }
  };

  const playGameOverSound = (isNewRecord: boolean) => {
    try {
      const ctx = getAudioContext();
      const osc = ctx.createOscillator();
      const gainNode = ctx.createGain();
      osc.connect(gainNode);
      gainNode.connect(ctx.destination);
      
      if (isNewRecord) {
        osc.type = "sawtooth";
        osc.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
        osc.frequency.setValueAtTime(659.25, ctx.currentTime + 0.1); // E5
        osc.frequency.setValueAtTime(783.99, ctx.currentTime + 0.2); // G5
        osc.frequency.setValueAtTime(1046.50, ctx.currentTime + 0.3); // C6
        gainNode.gain.setValueAtTime(0.08, ctx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.5);
        osc.start();
        osc.stop(ctx.currentTime + 0.5);
      } else {
        osc.type = "triangle";
        osc.frequency.setValueAtTime(392.00, ctx.currentTime); // G4
        osc.frequency.setValueAtTime(293.66, ctx.currentTime + 0.15); // D4
        gainNode.gain.setValueAtTime(0.12, ctx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.4);
        osc.start();
        osc.stop(ctx.currentTime + 0.4);
      }
    } catch (e) {}
  };

  // Spawn star inside the 640x480 boundary
  const spawnStar = () => {
    starRef.current = {
      x: Math.floor(Math.random() * (640 - 60)) + 30,
      y: Math.floor(Math.random() * (480 - 60)) + 30,
      r: 16
    };
  };

  // Dynamic scripts loading for MediaPipe
  useEffect(() => {
    if (controlMode === "webcam") {
      initWebcamMediaPipe();
    } else {
      stopWebcam();
    }
    return () => {
      stopWebcam();
    };
  }, [controlMode]);

  const stopWebcam = () => {
    isCameraIniting.current = false;
    if (cameraRef.current) {
      try {
        cameraRef.current.stop();
      } catch (e) {}
      cameraRef.current = null;
    }
    if (videoRef.current && videoRef.current.srcObject) {
      try {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
      } catch (e) {}
      videoRef.current.srcObject = null;
    }
    setCameraStatus("เปิดใช้งานโหมดควบคุมเมาส์แล้ว");
  };

  const initWebcamMediaPipe = async () => {
    if (isCameraIniting.current) return;
    isCameraIniting.current = true;
    setCameraStatus("กำลังเปิดใช้งานกล้องและโหลดไลบรารี AI...");

    try {
      // Lazy load MediaPipe script files if not loaded already
      if (!(window as any).Hands) {
        await new Promise<void>((resolve, reject) => {
          const script = document.createElement("script");
          script.src = "https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js";
          script.crossOrigin = "anonymous";
          script.onload = () => resolve();
          script.onerror = () => reject(new Error("Hands script load failed"));
          document.head.appendChild(script);
        });
      }

      if (!(window as any).Camera) {
        await new Promise<void>((resolve, reject) => {
          const script = document.createElement("script");
          script.src = "https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js";
          script.crossOrigin = "anonymous";
          script.onload = () => resolve();
          script.onerror = () => reject(new Error("Camera script load failed"));
          document.head.appendChild(script);
        });
      }

      const HandsClass = (window as any).Hands;
      const CameraClass = (window as any).Camera;

      if (!HandsClass || !CameraClass) {
        throw new Error("ระบบ MediaPipe ไม่พร้อมใช้งานในเบราว์เซอร์นี้");
      }

      // Setup Hands Detection
      const hands = new HandsClass({
        locateFile: (file: string) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
      });

      hands.setOptions({
        maxNumHands: 1,
        modelComplexity: 1,
        minDetectionConfidence: 0.5,
        minTrackingConfidence: 0.5
      });

      hands.onResults((results: any) => {
        if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
          const hand = results.multiHandLandmarks[0];
          // Index tip is landmark 8
          const indexTip = hand[8];
          // Invert X for mirroring
          pointerRef.current = {
            x: (1 - indexTip.x) * 640,
            y: indexTip.y * 480
          };
        }
      });

      handsRef.current = hands;

      if (videoRef.current) {
        const camera = new CameraClass(videoRef.current, {
          onFrame: async () => {
            if (videoRef.current && handsRef.current) {
              await handsRef.current.send({ image: videoRef.current });
            }
          },
          width: 640,
          height: 480
        });

        cameraRef.current = camera;
        await camera.start();
        setCameraStatus("🔴 กล้องเปิดใช้งานสำเร็จ ตรวจจับพอยเตอร์ด้วยข้อมือ/นิ้วชี้หน้าเลนส์");
      }
    } catch (err: any) {
      console.error(err);
      setCameraStatus("⚠️ อุปกรณ์กล้องไม่พร้อมทำงาน / เบราว์เซอร์ปฏิเสธ สลับเป็นโหมดเมาส์อัตโนมัติ");
      setControlMode("mouse");
    } finally {
      isCameraIniting.current = false;
    }
  };

  // Start / Reset Game
  const startGame = () => {
    getAudioContext(); // Resume audio
    setScore(0);
    currentScoreRef.current = 0;
    setTimeLeft(30);
    setGameActive(true);
    spawnStar();

    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          endGame();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const endGame = () => {
    setGameActive(false);
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }

    const finalScore = currentScoreRef.current;
    const isNewHighScore = currentUser ? finalScore > currentUser.high_score : false;
    
    playGameOverSound(isNewHighScore);

    // Save Score to database via fetch
    fetch("/api/update-score", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ score: finalScore })
    })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          if (data.new_record) {
            onScoreUpdate(data.high_score);
            alert(`🎮 หมดเวลาคัดเลือก!\n🏆 ยินดีด้วยคุณสร้าง NEW RECORD: ${finalScore} คะแนน!`);
          } else {
            alert(`🎮 หมดเวลา!\nคุณทำได้ ${finalScore} คะแนน (คะแนนสูงสุด: ${data.high_score} คะแนน)`);
          }
        }
      })
      .catch(err => {
        console.error("Failed to update score:", err);
        alert(`🎮 หมดเวลา! คุณทำได้ ${finalScore} คะแนน`);
      });
  };

  // Canvas drawing render loop
  useEffect(() => {
    let animId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const render = () => {
      if (!gameActive) {
        ctx.clearRect(0, 0, 640, 480);
        
        // Draw elegant standby screen
        ctx.fillStyle = "rgba(0, 0, 0, 0.75)";
        ctx.fillRect(0, 0, 640, 480);
        
        ctx.fillStyle = "#00f0ff";
        ctx.font = "900 24px 'Orbitron', sans-serif";
        ctx.textAlign = "center";
        ctx.fillText("READY FOR SELECTION", 320, 220);
        
        ctx.fillStyle = "#ffffff";
        ctx.font = "400 13px 'Prompt', sans-serif";
        ctx.fillText("กรุณากดปุ่ม START TEST ด้านล่างเพื่อเริ่มการทดสอบจับเวลา 30 วินาที", 320, 260);
        
        return;
      }

      // 1. Collision detection
      const ptr = pointerRef.current;
      const star = starRef.current;
      const dist = Math.hypot(ptr.x - star.x, ptr.y - star.y);
      if (dist < star.r + 15) {
        currentScoreRef.current += 1;
        setScore(currentScoreRef.current);
        playScoreSound();
        spawnStar();
      }

      // 2. Clear canvas (if webcam, we keep webcam overlay background transparent)
      ctx.clearRect(0, 0, 640, 480);

      // 3. Draw star
      ctx.shadowBlur = 15;
      ctx.shadowColor = "rgba(255, 0, 127, 0.8)";
      ctx.fillStyle = "#ff007f";
      
      ctx.beginPath();
      const spikes = 5;
      const outerRadius = star.r;
      const innerRadius = star.r / 2;
      let rot = (Math.PI / 2) * 3;
      let x = star.x;
      let y = star.y;
      const step = Math.PI / spikes;

      for (let i = 0; i < spikes; i++) {
        x = star.x + Math.cos(rot) * outerRadius;
        y = star.y + Math.sin(rot) * outerRadius;
        ctx.lineTo(x, y);
        rot += step;

        x = star.x + Math.cos(rot) * innerRadius;
        y = star.y + Math.sin(rot) * innerRadius;
        ctx.lineTo(x, y);
        rot += step;
      }
      ctx.lineTo(star.x, star.y - outerRadius);
      ctx.closePath();
      ctx.fill();

      // 4. Draw Cursor Ring
      ctx.shadowBlur = 15;
      ctx.shadowColor = "rgba(0, 240, 255, 0.8)";
      ctx.strokeStyle = "#00f0ff";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(ptr.x, ptr.y, 14, 0, Math.PI * 2);
      ctx.stroke();

      ctx.fillStyle = "#00f0ff";
      ctx.beginPath();
      ctx.arc(ptr.x, ptr.y, 3, 0, Math.PI * 2);
      ctx.fill();

      ctx.shadowBlur = 0; // Reset

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [gameActive]);

  // Handle Mouse movement in canvas area
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (controlMode !== "mouse") return;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    pointerRef.current = {
      x: ((e.clientX - rect.left) / rect.width) * 640,
      y: ((e.clientY - rect.top) / rect.height) * 480
    };
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (controlMode !== "mouse") return;
    if (e.touches.length === 0) return;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const touch = e.touches[0];
    pointerRef.current = {
      x: ((touch.clientX - rect.left) / rect.width) * 640,
      y: ((touch.clientY - rect.top) / rect.height) * 480
    };
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Left Side: Controls & Info */}
        <div className="md:col-span-4 flex flex-col justify-between glass-card p-5 rounded-xl">
          <div>
            <h3 className="font-orbitron font-bold text-white text-base border-b border-white/10 pb-2 mb-4 flex items-center gap-2">
              <Trophy className="w-5 h-5 text-neon-blue" />
              <span>LIVE SELECTION STATS</span>
            </h3>

            {/* Scoreboard Cards */}
            <div className="grid grid-cols-2 gap-3 mb-6">
              <div className="bg-black/50 border border-white/5 rounded-lg p-3 text-center">
                <span className="text-[10px] text-gray-400 font-medium">คะแนนปัจจุบัน</span>
                <div className="font-orbitron font-black text-2xl text-neon-green mt-1">{score}</div>
              </div>
              <div className="bg-black/50 border border-white/5 rounded-lg p-3 text-center">
                <span className="text-[10px] text-gray-400 font-medium">สถิติสูงสุดของคุณ</span>
                <div className="font-orbitron font-black text-2xl text-neon-blue mt-1">
                  {currentUser ? currentUser.high_score : 0}
                </div>
              </div>
            </div>

            {/* Mode Select */}
            <div className="mb-5">
              <label className="text-xs font-semibold text-neon-pink flex items-center gap-1 mb-2">
                เลือกโหมดควบคุมเกมมินิ
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setControlMode("mouse")}
                  className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded text-xs font-semibold transition-all duration-300 border ${
                    controlMode === "mouse"
                      ? "bg-neon-pink/20 text-white border-neon-pink shadow-[0_0_8px_rgba(255,0,127,0.3)]"
                      : "bg-transparent text-gray-400 border-white/10 hover:border-white/30 hover:bg-white/5"
                  }`}
                >
                  <MousePointer className="w-4 h-4" />
                  <span>เมาส์ / สัมผัส</span>
                </button>
                <button
                  onClick={() => setControlMode("webcam")}
                  className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded text-xs font-semibold transition-all duration-300 border ${
                    controlMode === "webcam"
                      ? "bg-neon-blue/20 text-white border-neon-blue shadow-[0_0_8px_rgba(0,240,255,0.3)]"
                      : "bg-transparent text-gray-400 border-white/10 hover:border-white/30 hover:bg-white/5"
                  }`}
                >
                  <Video className="w-4 h-4" />
                  <span>กล้อง AR มือ</span>
                </button>
              </div>
            </div>

            {/* Instruction list */}
            <div className="bg-white/5 border border-white/10 rounded-lg p-3.5 space-y-2">
              <h5 className="text-[11px] font-bold text-gray-300 flex items-center gap-1.5 uppercase tracking-wide">
                <Volume2 className="w-3.5 h-3.5 text-neon-green" /> คำแนะนำการทำคะแนน
              </h5>
              <p className="text-[11px] text-gray-400 leading-relaxed">
                เป้าหมายคือเลื่อนพอยเตอร์กลมสีฟ้าครอบดวงดาวสีชมพูที่สุ่มขึ้นมาบนหน้าจอเพื่อสะสมแต้มให้ได้มากที่สุดภายใน 30 วินาที ระบบจะเซฟคะแนนลงฐานข้อมูลอัตโนมัติเฉพาะเมื่อทำคะแนนได้สูงสุดกว่าสถิติเดิม
              </p>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-white/10">
            <button
              onClick={startGame}
              disabled={gameActive}
              className="w-full bg-gradient-to-r from-neon-blue to-neon-pink text-black font-orbitron font-black text-base py-3.5 rounded-lg tracking-wider hover:opacity-90 disabled:opacity-40 shadow-[0_0_15px_rgba(0,240,255,0.3)] transition-all duration-300"
            >
              {gameActive ? `PLAYING (${timeLeft}s)` : "START TESTING"}
            </button>
          </div>
        </div>

        {/* Right Side: Active Game Arena */}
        <div className="md:col-span-8 glass-card p-5 rounded-xl flex flex-col">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-orbitron font-bold text-gray-400 tracking-wider flex items-center gap-1.5">
              <span className="inline-block w-2 h-2 rounded-full bg-neon-pink animate-pulse" />
              LIVE TEST ARENA
            </span>
            <div className="bg-neon-pink/10 border border-neon-pink/20 text-neon-pink text-xs font-orbitron font-black px-3 py-1 rounded">
              TIME LEFT: {timeLeft}s
            </div>
          </div>

          {/* Game Window with Canvas and Video overlay */}
          <div className="relative w-full aspect-video bg-black rounded-lg overflow-hidden border border-white/10 flex items-center justify-center shadow-[inset_0_0_20px_rgba(0,0,0,0.8)]">
            {/* Webcam hidden/mirrored representation */}
            <video
              ref={videoRef}
              id="webcam-preview"
              className={`absolute inset-0 w-full h-full object-cover -scale-x-100 transition-opacity duration-300 z-10 ${
                controlMode === "webcam" && gameActive ? "opacity-35" : "opacity-0 pointer-events-none"
              }`}
              autoPlay
              playsInline
              muted
            />

            {/* Game Overlay Canvas */}
            <canvas
              ref={canvasRef}
              width={640}
              height={480}
              onMouseMove={handleMouseMove}
              onTouchMove={handleTouchMove}
              className="absolute inset-0 w-full h-full z-20 cursor-crosshair touch-none"
            />
          </div>

          {/* Camera Status Text indicator */}
          <div className="mt-3 flex items-start gap-2 bg-white/5 border border-white/5 rounded px-3 py-2 text-xs text-gray-400">
            <Info className="w-4 h-4 text-neon-blue shrink-0 mt-0.5" />
            <p className="leading-tight">{cameraStatus}</p>
          </div>
        </div>
      </div>
    </div>
  );
};
