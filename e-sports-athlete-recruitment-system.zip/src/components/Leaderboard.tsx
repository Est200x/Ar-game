import React from "react";
import { LeaderboardEntry } from "../types";
import { Award, Medal, Zap, Star } from "lucide-react";

interface LeaderboardProps {
  entries: LeaderboardEntry[];
  loading: boolean;
}

export const Leaderboard: React.FC<LeaderboardProps> = ({ entries, loading }) => {
  return (
    <div className="glass-card p-5 rounded-xl flex flex-col h-full">
      <div className="flex items-center justify-between mb-4 pb-2 border-b border-white/10">
        <h4 className="font-orbitron font-bold text-white text-sm flex items-center gap-2">
          <Award className="w-5 h-5 text-neon-pink" />
          <span>LEADERBOARD คัดเลือก</span>
        </h4>
        <span className="text-[10px] bg-neon-pink/15 text-neon-pink px-2.5 py-0.5 rounded font-bold font-orbitron">
          TOP RANKS
        </span>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-10 flex-grow">
          <div className="animate-pulse flex space-x-2">
            <div className="w-2 h-2 bg-neon-blue rounded-full"></div>
            <div className="w-2 h-2 bg-neon-pink rounded-full"></div>
            <div className="w-2 h-2 bg-neon-green rounded-full"></div>
          </div>
          <span className="text-xs text-gray-400 mt-2 font-orbitron">REFRESHING...</span>
        </div>
      ) : entries.length === 0 ? (
        <div className="text-center py-8 text-xs text-gray-500">
          ยังไม่มีข้อมูลผู้ท้าชิงขณะนี้
        </div>
      ) : (
        <div className="space-y-2 max-h-[360px] overflow-y-auto pr-1">
          {entries.slice(0, 10).map((entry, index) => {
            const isTop3 = index < 3;
            const rankColors = [
              "from-yellow-500/20 to-yellow-500/5 border-yellow-500/30 text-yellow-400",
              "from-slate-300/20 to-slate-300/5 border-slate-300/30 text-slate-300",
              "from-amber-600/20 to-amber-600/5 border-amber-600/30 text-amber-500"
            ];
            const currentRankColor = isTop3 ? rankColors[index] : "from-white/5 to-transparent border-white/5 text-gray-400";

            return (
              <div
                key={entry.id}
                className={`flex items-center justify-between p-3 rounded-lg bg-gradient-to-r border transition-all duration-300 hover:border-white/25 ${currentRankColor}`}
              >
                <div className="flex items-center gap-3">
                  {/* Rank Badge */}
                  <div className="w-6 h-6 flex items-center justify-center font-orbitron font-black text-xs rounded-full bg-black/60 border border-white/10 shrink-0">
                    {index === 0 ? (
                      <Medal className="w-3.5 h-3.5 text-yellow-400" />
                    ) : index === 1 ? (
                      <Medal className="w-3.5 h-3.5 text-slate-300" />
                    ) : index === 2 ? (
                      <Medal className="w-3.5 h-3.5 text-amber-500" />
                    ) : (
                      index + 1
                    )}
                  </div>

                  <div>
                    <span className="text-xs font-semibold text-white block">
                      {entry.name}
                    </span>
                    <span className="text-[10px] text-gray-400 font-mono">
                      @{entry.username}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1 bg-black/40 border border-white/10 px-2.5 py-1 rounded font-orbitron">
                  <Star className="w-3 h-3 text-neon-pink fill-neon-pink" />
                  <span className="text-xs font-bold text-neon-green">{entry.high_score}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <div className="mt-4 pt-3 border-t border-white/10 text-[10px] text-gray-500 text-center flex items-center justify-center gap-1.5">
        <Zap className="w-3.5 h-3.5 text-neon-blue animate-bounce" />
        <span>ข้อมูลสถิติคะแนนทั้งหมดอ้างอิงจากฐานข้อมูลกลาง</span>
      </div>
    </div>
  );
};
