import React, { useState } from "react";
import { PHPFiles } from "../types";
import { Copy, Check, Terminal, FileCode, CheckCircle, Database, HelpCircle } from "lucide-react";

interface CodeViewerProps {
  files: PHPFiles | null;
  loading: boolean;
  errorMsg: string;
}

export const CodeViewer: React.FC<CodeViewerProps> = ({ files, loading, errorMsg }) => {
  const [activeTab, setActiveTab] = useState<keyof PHPFiles>("index.php");
  const [copied, setCopied] = useState<boolean>(false);

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const fileDescriptions: Record<keyof PHPFiles, string> = {
    "schema.sql": "คำสั่ง SQL สำหรับนำเข้าฐานข้อมูลเพื่อสร้างฐานข้อมูล esports_recruitment และตาราง users ใน phpMyAdmin",
    "config.php": "ไฟล์เชื่อมต่อฐานข้อมูล MySQL ด้วย PDO แบบปลอดภัย พร้อมระบบตรวจเช็คและเริ่ม Session",
    "index.php": "หน้าหลัก แสดงคำอธิบาย ข้อมูลแนะนำโครงการรับสมัคร และฟอร์ม Login เข้าสู่ระบบที่ปลอดภัย",
    "register.php": "หน้าสำหรับสมัครสมาชิก ลงทะเบียนเก็บข้อมูล ชื่อ-นามสกุล, อีเมล, ยูสเซอร์ และแฮชรหัสผ่านลงฐานข้อมูล",
    "game.php": "หน้ามินิเกมดักจับข้อมือ (AR Hand Tracking) ด้วยกล้อง Webcam และส่งสถิติคะแนนด้วย AJAX",
    "update_score.php": "ไฟล์หลังบ้านสำหรับรับคะแนนผ่าน AJAX และเซฟค่าใหม่เฉพาะเมื่อสูงกว่าสถิติเดิม",
    "logout.php": "หน้าสำหรับทำลาย Session และทำการล้างคุกกี้เพื่อนำทางผู้ใช้ออกจากระบบกลับหน้าล็อกอิน",
  };

  if (loading) {
    return (
      <div className="bg-black/40 border border-white/10 rounded-xl p-8 flex flex-col items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-neon-blue"></div>
        <p className="mt-4 text-sm text-gray-400 font-orbitron">LOADING PHP SOURCE CODE...</p>
      </div>
    );
  }

  if (errorMsg || !files) {
    return (
      <div className="bg-black/40 border border-red-500/20 rounded-xl p-6 text-center">
        <p className="text-red-400 font-bold">เกิดข้อผิดพลาดในการดึงโค้ด PHP/MySQL</p>
        <p className="text-xs text-gray-400 mt-2">{errorMsg || "ไม่สามารถอ่านไฟล์ต้นฉบับได้"}</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6 glass-card p-6 rounded-xl animate-fade-in">
      {/* Installation Instruction Banner */}
      <div className="bg-gradient-to-r from-neon-blue/10 to-neon-pink/10 border border-neon-blue/20 rounded-lg p-5">
        <h4 className="text-sm font-orbitron font-bold text-neon-blue flex items-center gap-2 mb-3">
          <Database className="w-4 h-4" />
          คู่มือการติดตั้งบน XAMPP (Localhost)
        </h4>
        <ol className="text-xs text-gray-300 space-y-2 list-decimal list-inside pl-1">
          <li>เปิดโปรแกรม <strong className="text-white">XAMPP Control Panel</strong> สตาร์ท <strong className="text-neon-blue">Apache</strong> และ <strong className="text-neon-blue">MySQL</strong></li>
          <li>เข้าไปที่โฟลเดอร์ติดตั้งของ XAMPP โดยทั่วไปคือ <code className="bg-white/10 px-1 py-0.5 rounded text-neon-pink">C:\xampp\htdocs\</code></li>
          <li>สร้างโฟลเดอร์ใหม่ชื่อ <code className="bg-white/10 px-1 py-0.5 rounded text-white">esports_recruitment</code></li>
          <li>นำโค้ดจากแท็บด้านล่างไปสร้างไฟล์ใส่ในโฟลเดอร์ดังกล่าวตามชื่อไฟล์ให้ครบ</li>
          <li>เปิดบราวเซอร์เข้า <code className="text-neon-blue font-semibold">http://localhost/phpmyadmin</code> จากนั้นสร้างฐานข้อมูล หรือกดแท็บ SQL แล้วนำคำสั่งในไฟล์ <strong className="text-neon-pink">schema.sql</strong> ไปวางรันเพื่อสร้างตารางข้อมูล</li>
          <li>เข้าเล่นและทดสอบระบบได้ผ่านลิงก์ <code className="text-neon-blue font-semibold">http://localhost/esports_recruitment/</code></li>
        </ol>
      </div>

      {/* Code Browser */}
      <div>
        <div className="flex items-center justify-between mb-3 border-b border-white/10 pb-2">
          <div className="flex items-center gap-2">
            <FileCode className="w-5 h-5 text-neon-pink" />
            <h3 className="font-orbitron font-bold text-white tracking-wider text-sm">XAMPP PROJECT FILES</h3>
          </div>
          <p className="text-xs text-gray-400 hidden sm:block">คัดลอกแต่ละไฟล์ไปใส่ใน htdocs ได้เลย</p>
        </div>

        {/* Tab Selection */}
        <div className="flex flex-wrap gap-1.5 mb-3">
          {(Object.keys(files) as Array<keyof PHPFiles>).map((fileName) => (
            <button
              key={fileName}
              onClick={() => {
                setActiveTab(fileName);
                setCopied(false);
              }}
              className={`px-3 py-1.5 rounded text-xs font-mono font-medium transition-all duration-200 ${
                activeTab === fileName
                  ? "bg-neon-pink text-white shadow-[0_0_8px_rgba(255,0,127,0.4)]"
                  : "bg-white/5 text-gray-300 hover:bg-white/10 border border-white/5"
              }`}
            >
              {fileName}
            </button>
          ))}
        </div>

        {/* File Details and Code Block */}
        <div className="bg-black/80 rounded-xl border border-white/10 overflow-hidden">
          <div className="bg-white/5 px-4 py-2.5 border-b border-white/10 flex items-center justify-between">
            <div className="text-[11px] text-gray-400 max-w-[80%]">
              <span className="text-neon-blue font-mono font-semibold">คำอธิบาย:</span> {fileDescriptions[activeTab]}
            </div>
            <button
              onClick={() => handleCopy(files[activeTab])}
              className="flex items-center gap-1 bg-white/10 hover:bg-white/20 text-white px-2.5 py-1 rounded text-xs transition-colors"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-neon-green" />
                  <span className="text-neon-green font-semibold">คัดลอกแล้ว!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>คัดลอกโค้ด</span>
                </>
              )}
            </button>
          </div>

          <div className="p-4 overflow-x-auto max-h-[500px]">
            <pre className="text-xs font-mono text-gray-300 select-all leading-relaxed whitespace-pre-wrap">
              <code>{files[activeTab]}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
