export interface User {
  id: number;
  username: string;
  name: string;
  email: string;
  high_score: number;
}

export interface LeaderboardEntry {
  id: number;
  username: string;
  name: string;
  high_score: number;
}

export interface PHPFiles {
  "schema.sql": string;
  "config.php": string;
  "index.php": string;
  "register.php": string;
  "game.php": string;
  "update_score.php": string;
  "logout.php": string;
}
